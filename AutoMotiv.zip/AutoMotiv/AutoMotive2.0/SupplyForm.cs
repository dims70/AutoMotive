﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImdLib7;

namespace AutoMotive2._0
{
    public partial class SupplyForm : Form
    {
        public SupplyForm()
        {
            InitializeComponent();
            comboIdDet.FillComboBoxFromQueryOleDB("КодЗапчасти","Склад");
            dataGridView1.FillDataGridFromQueryOleDB("*", "Склад");
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();

        private void btnAccept_Click(object sender, EventArgs e)
        {
            new OleDbCommand($"update Склад set Количество = Количество + {countDet.Value} where КодЗапчасти = {comboIdDet.SelectedItem.ToString()}",ConnectionOleDB.getConnection()).ExecuteNonQuery();
            MessageBox.Show("Запчасти добавлены");
            dataGridView1.FillDataGridFromQueryOleDB("*", "Склад");
        }
    }
}
