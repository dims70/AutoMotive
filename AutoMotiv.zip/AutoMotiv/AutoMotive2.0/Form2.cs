﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;
using ImdLib7;

namespace AutoMotive2._0
{
    public partial class SkladForm : Form
    {

        public SkladForm()
        {
            InitializeComponent();
            dataGridView1.FillDataGridFromQueryOleDB("*", "Склад");
            ModelNameBox.SelectedItem = "(нет)";
            MarkNameBox.SelectedItem = "(нет)";
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();

        private void SkladForm_Load(object sender, EventArgs e)
        {
            MarkNameBox.FillComboBoxFromQueryOleDB("Название", "Марка");
            ModelNameBox.FillComboBoxFromQueryOleDB("НазваниеМарки", "Модель");
        }

        private void MarkNameBox_TextChanged(object sender, EventArgs e) => ModelNameBox.Text = null;

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(MarkNameBox.SelectedItem.ToString()=="(нет)" && ModelNameBox.SelectedItem.ToString()=="(нет)")
            {
                dataGridView1.FillDataGridFromQueryOleDB("*", "Склад");
            }
            else
            {   
                if (ModelNameBox.SelectedItem.ToString()=="(нет)")
                {
                    if (MarkNameBox.SelectedItem.ToString() != "(нет)")
                    {
                        dataGridView1.FillDataGridFromLongQueryOleDB($"select * from Склад where " +
                            $"КодМарки = (select КодМарки from Марка where " +
                            $"Название = '{MarkNameBox.SelectedItem.ToString()}')","Склад");
                    }
                }
                if ( MarkNameBox.SelectedItem.ToString() == "(нет)")
                {
                    if (ModelNameBox.SelectedItem.ToString() != "(нет)")
                    {
                        dataGridView1.FillDataGridFromLongQueryOleDB($"select * from Склад where " +
                            $"КодМодели = (select КодМодели from Модель where " +
                            $"НазваниеМарки = '{ModelNameBox.SelectedItem.ToString()}')", "Склад");
                    }
                }
                if(MarkNameBox.SelectedItem.ToString()!="(нет)"  && ModelNameBox.SelectedItem.ToString()!="(нет)")
                {
                    dataGridView1.FillDataGridFromLongQueryOleDB($"select * from Склад where " +
                        $"КодМарки = (select КодМарки from Марка where " +
                        $"Название = '{MarkNameBox.SelectedItem.ToString()}') " +
                        $"and " +
                        $"КодМодели = (select КодМодели from Модель where " +
                        $"НазваниеМарки = '{ModelNameBox.SelectedItem.ToString()}')","Склад");
                }
                
            }
        }
    }
}
