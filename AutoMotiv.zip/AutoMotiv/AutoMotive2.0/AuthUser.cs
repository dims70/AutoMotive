﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoMotive2._0
{
    public static class AuthUser
    {
        public static int id { get; set; }
        public static string login { get; set; }
    }
}
