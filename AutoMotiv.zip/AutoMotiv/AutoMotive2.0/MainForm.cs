﻿using System;
using System.Threading;
using System.Windows.Forms;
using ImdLib7;

namespace AutoMotive2._0
{
    public partial class MainForm : Form
    {
        #region Delegate_timer
        public delegate void DelegateForTime(Label label); //делегат для работы с лейблом
        DelegateForTime DelTime; //поле типа делегата
        Thread ClockThread; //сам поток
        #endregion

        public MainForm()
        {
            InitializeComponent();
            DelTime = new DelegateForTime(StartTime); //даём метод делегату
            CustomDesign();
            Load += Form1_Load;
            FormClosed += Form1_FormClosed;
            btnCatalogueMenu.Click += btnCatalogueMenu_Click;
            btnSklad.Click += btnSklad_Click;
            button1.Click += button1_Click;
            btnSkladMenu.Click += btnSkladMenu_Click;
            SkladCatalogue.Click += button4_Click;
            button3.Click += button3_Click;
            btnHelpMenu.Click += btnHelpMenu_Click;
            

        }

        #region FormLoad
        private void Form1_Load(object sender, EventArgs e)
        {
            ClockThread = new Thread(LabelTime); //создаём новый поток
            ClockThread.IsBackground = true; //ставим поток в фоновый режим
            ClockThread.Priority = ThreadPriority.Lowest; //даём потоку низкий приоритет
            ClockThread.Start(); //запускаем поток
        }
        #endregion

        #region FormClosed
        private void Form1_FormClosed(object sender, FormClosedEventArgs e) => ClockThread.Abort(); //закрываем поток по закрытию программы
        #endregion

        #region startTime
        void StartTime(Label label) //устанавливаю время
        {
            string s = DateTime.Now.Hour.ToString("00");
            s += " : ";
            s += DateTime.Now.Minute.ToString("00");

            s += " : " + DateTime.Now.Second.ToString("00");
            label.Text = s;
        }
        #endregion

        #region LabelTime
        void LabelTime() //бесконечно запускаю цикл с методом из главного потока
        {
            while (true)
            {
                Invoke(DelTime, TimeLabel);
            }
        }
        #endregion

        #region customDesign
        private void CustomDesign()
        {
            panelCatalogueSubMenu.Visible = false;
            panelSkladSubMenu.Visible = false;
        }
        #endregion

        #region hideSubMenu
        private void hideSubMenu()
        {
            if (panelCatalogueSubMenu.Visible == true)
                panelCatalogueSubMenu.Visible = false;
            if (panelSkladSubMenu.Visible == true)
                panelSkladSubMenu.Visible = false;
        }
        #endregion

        #region showSubMenu
        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }
        #endregion

        #region btnCatalogueMenu
        private void btnCatalogueMenu_Click(object sender, EventArgs e)
        {
            showSubMenu(panelCatalogueSubMenu);
        }
        #endregion

        #region btnSklad
        private void btnSklad_Click(object sender, EventArgs e)
        {
            //...
            //Код..
            //...
            hideSubMenu();
        }
        #endregion

        #region btn1
        private void button1_Click(object sender, EventArgs e)
        {

            //...
            //Код..
            //...
            hideSubMenu();
        }
        #endregion

        #region btnSkladMenu
        private void btnSkladMenu_Click(object sender, EventArgs e)
        {

            showSubMenu(panelSkladSubMenu);
        }
        #endregion

        #region btn4
        private void button4_Click(object sender, EventArgs e)
        {

            openChildForm(new SkladForm());
            hideSubMenu();
        }
        #endregion

        #region btn3
        private void button3_Click(object sender, EventArgs e)
        {

            //...
            //Код..
            //...
            hideSubMenu();
        }
        #endregion
        //----------------------------------------------------------
        #region helpBtn
        private void btnHelpMenu_Click(object sender, EventArgs e)
        {
            //...
            //Код..
            //...
            hideSubMenu();
        }
        #endregion

        #region ExitBtn
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            //...
            //Код..
            //...
            hideSubMenu();
        }
        #endregion

        #region OpenChildForm 
        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        #endregion

        private void ExitBtn_Click_1(object sender, EventArgs e) => Close();

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e) => DialogResult = DialogResult.OK;

        private void button3_Click_1(object sender, EventArgs e)
        {
            openChildForm(new SupplierForm());
            hideSubMenu();
        }

        private void btnHelpMenu_Click_1(object sender, EventArgs e)
        {
            openChildForm(new FeedbackForm());
        }

        private void btnSklad_Click_1(object sender, EventArgs e)
        {
            openChildForm(new OrderForm());
            hideSubMenu();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            openChildForm(new SupplyForm());
            hideSubMenu();
        }

        private void btnCreateDetails_Click(object sender, EventArgs e)
        {
            openChildForm(new CreateDetails());
            hideSubMenu();
        }
    }
}