﻿using ImdLib7;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoMotive2._0
{
    public partial class SupplierForm : Form
    {
        public SupplierForm()
        {
            InitializeComponent();
            tabControl1.SelectTab(tabPage2);
            dataGridView1.FillDataGridFromQueryOleDB("*", "Поставщик");
            btnEdit.Click += btnEdit_Click;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            tabControl1.SelectTab(tabPage1);
            btnSave.Text = "Создать";
            idSuppBox.Clear();
            modelbox.Value = 0;
            namesupp.Clear();
            xBox.Value = 0;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count != 0)
            {
                tabControl1.SelectTab(tabPage1);
                btnSave.Text = "Сохранить";
                idSuppBox.Text =dataGridView1.SelectedCells[0].Value.ToString();
                modelbox.Value = Convert.ToDecimal(dataGridView1.SelectedCells[1].Value);
                namesupp.Text = (string)dataGridView1.SelectedCells[2].Value;
                xBox.Value = Convert.ToDecimal(dataGridView1.SelectedCells[3].Value);
            }
            else
            {
                MessageBox.Show("Сначала выберите строку для редактирования");
            }
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (btnSave.Text == "Создать")
            {
                try
                {
                    new OleDbCommand($"insert into Поставщик(КодМодели,НазваниеПоставщика,МножительЦены) " +
                        $"values ('{modelbox.Value}','{namesupp.Text}','{xBox.Value}')", 
                        ConnectionOleDB.getConnection())
                        .ExecuteNonQuery();
                    MessageBox.Show("Поставщик добавлен");
                    dataGridView1.FillDataGridFromQueryOleDB("*", "Поставщик");
                }
                catch
                {
                    MessageBox.Show("Введите верные данные.");
                }

            }
            else
            {
                new OleDbCommand($"update Поставщик set " +
                    $"КодМодели = '{modelbox.Value}', " +
                    $"НазваниеПоставщика = '{namesupp.Text}', " +
                    $"МножительЦены = '{xBox.Value}' " +
                    $"where КодПоставщика = {idSuppBox.Text}", ConnectionOleDB.getConnection())
                    .ExecuteNonQuery();
                MessageBox.Show("Данные поставщика изменены");
                dataGridView1.FillDataGridFromQueryOleDB("*", "Поставщик");
            }
        }

        private void SupplierForm_Load(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new OleDbCommand($"delete from Поставщик where КодПоставщика = {Convert.ToInt32(dataGridView1.SelectedCells[0].Value)}",ConnectionOleDB.getConnection()).ExecuteNonQuery();
            MessageBox.Show("Поставщик удален.");
            dataGridView1.FillDataGridFromQueryOleDB("*","Поставщик");
        }
    }
}
