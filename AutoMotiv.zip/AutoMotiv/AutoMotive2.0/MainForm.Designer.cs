﻿namespace AutoMotive2._0
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.TimeLabel = new System.Windows.Forms.Label();
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.btnHelpMenu = new System.Windows.Forms.Button();
            this.panelSkladSubMenu = new System.Windows.Forms.Panel();
            this.btnCreateDetails = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SkladCatalogue = new System.Windows.Forms.Button();
            this.btnSkladMenu = new System.Windows.Forms.Button();
            this.panelCatalogueSubMenu = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSklad = new System.Windows.Forms.Button();
            this.btnCatalogueMenu = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelSideMenu.SuspendLayout();
            this.panelSkladSubMenu.SuspendLayout();
            this.panelCatalogueSubMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelChildForm
            // 
            this.panelChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildForm.Location = new System.Drawing.Point(200, 0);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(750, 650);
            this.panelChildForm.TabIndex = 3;
            // 
            // TimeLabel
            // 
            this.TimeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TimeLabel.AutoSize = true;
            this.TimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.TimeLabel.ForeColor = System.Drawing.Color.White;
            this.TimeLabel.Location = new System.Drawing.Point(44, 40);
            this.TimeLabel.Name = "TimeLabel";
            this.TimeLabel.Size = new System.Drawing.Size(51, 20);
            this.TimeLabel.TabIndex = 0;
            this.TimeLabel.Text = "label1";
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.AutoScroll = true;
            this.panelSideMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panelSideMenu.Controls.Add(this.ExitBtn);
            this.panelSideMenu.Controls.Add(this.btnHelpMenu);
            this.panelSideMenu.Controls.Add(this.panelSkladSubMenu);
            this.panelSideMenu.Controls.Add(this.btnSkladMenu);
            this.panelSideMenu.Controls.Add(this.panelCatalogueSubMenu);
            this.panelSideMenu.Controls.Add(this.btnCatalogueMenu);
            this.panelSideMenu.Controls.Add(this.panel1);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(200, 650);
            this.panelSideMenu.TabIndex = 2;
            // 
            // ExitBtn
            // 
            this.ExitBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ExitBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ExitBtn.FlatAppearance.BorderSize = 0;
            this.ExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExitBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ExitBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.ExitBtn.Location = new System.Drawing.Point(0, 605);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.ExitBtn.Size = new System.Drawing.Size(200, 45);
            this.ExitBtn.TabIndex = 7;
            this.ExitBtn.Text = "Выход";
            this.ExitBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click_1);
            // 
            // btnHelpMenu
            // 
            this.btnHelpMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHelpMenu.FlatAppearance.BorderSize = 0;
            this.btnHelpMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelpMenu.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnHelpMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnHelpMenu.Location = new System.Drawing.Point(0, 409);
            this.btnHelpMenu.Name = "btnHelpMenu";
            this.btnHelpMenu.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnHelpMenu.Size = new System.Drawing.Size(200, 45);
            this.btnHelpMenu.TabIndex = 5;
            this.btnHelpMenu.Text = "Тех.Поддержка";
            this.btnHelpMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHelpMenu.UseVisualStyleBackColor = true;
            this.btnHelpMenu.Click += new System.EventHandler(this.btnHelpMenu_Click_1);
            // 
            // panelSkladSubMenu
            // 
            this.panelSkladSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelSkladSubMenu.Controls.Add(this.btnCreateDetails);
            this.panelSkladSubMenu.Controls.Add(this.button3);
            this.panelSkladSubMenu.Controls.Add(this.SkladCatalogue);
            this.panelSkladSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSkladSubMenu.Location = new System.Drawing.Point(0, 277);
            this.panelSkladSubMenu.Name = "panelSkladSubMenu";
            this.panelSkladSubMenu.Size = new System.Drawing.Size(200, 132);
            this.panelSkladSubMenu.TabIndex = 4;
            // 
            // btnCreateDetails
            // 
            this.btnCreateDetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCreateDetails.FlatAppearance.BorderSize = 0;
            this.btnCreateDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateDetails.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCreateDetails.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.btnCreateDetails.Location = new System.Drawing.Point(0, 87);
            this.btnCreateDetails.Name = "btnCreateDetails";
            this.btnCreateDetails.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnCreateDetails.Size = new System.Drawing.Size(200, 47);
            this.btnCreateDetails.TabIndex = 2;
            this.btnCreateDetails.Text = "Добавить запчасть";
            this.btnCreateDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCreateDetails.UseVisualStyleBackColor = true;
            this.btnCreateDetails.Click += new System.EventHandler(this.btnCreateDetails_Click);
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.button3.Location = new System.Drawing.Point(0, 40);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(200, 47);
            this.button3.TabIndex = 1;
            this.button3.Text = "Управление поставщиками";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // SkladCatalogue
            // 
            this.SkladCatalogue.Dock = System.Windows.Forms.DockStyle.Top;
            this.SkladCatalogue.FlatAppearance.BorderSize = 0;
            this.SkladCatalogue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SkladCatalogue.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SkladCatalogue.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.SkladCatalogue.Location = new System.Drawing.Point(0, 0);
            this.SkladCatalogue.Name = "SkladCatalogue";
            this.SkladCatalogue.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.SkladCatalogue.Size = new System.Drawing.Size(200, 40);
            this.SkladCatalogue.TabIndex = 0;
            this.SkladCatalogue.Text = "Просмотреть склад";
            this.SkladCatalogue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SkladCatalogue.UseVisualStyleBackColor = true;
            // 
            // btnSkladMenu
            // 
            this.btnSkladMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSkladMenu.FlatAppearance.BorderSize = 0;
            this.btnSkladMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSkladMenu.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSkladMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSkladMenu.Location = new System.Drawing.Point(0, 232);
            this.btnSkladMenu.Name = "btnSkladMenu";
            this.btnSkladMenu.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSkladMenu.Size = new System.Drawing.Size(200, 45);
            this.btnSkladMenu.TabIndex = 3;
            this.btnSkladMenu.Text = "Склад";
            this.btnSkladMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSkladMenu.UseVisualStyleBackColor = true;
            // 
            // panelCatalogueSubMenu
            // 
            this.panelCatalogueSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelCatalogueSubMenu.Controls.Add(this.button1);
            this.panelCatalogueSubMenu.Controls.Add(this.btnSklad);
            this.panelCatalogueSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCatalogueSubMenu.Location = new System.Drawing.Point(0, 145);
            this.panelCatalogueSubMenu.Name = "panelCatalogueSubMenu";
            this.panelCatalogueSubMenu.Size = new System.Drawing.Size(200, 87);
            this.panelCatalogueSubMenu.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.button1.Location = new System.Drawing.Point(0, 40);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(200, 40);
            this.button1.TabIndex = 1;
            this.button1.Text = "Принять поставку";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnSklad
            // 
            this.btnSklad.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSklad.FlatAppearance.BorderSize = 0;
            this.btnSklad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSklad.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSklad.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.btnSklad.Location = new System.Drawing.Point(0, 0);
            this.btnSklad.Name = "btnSklad";
            this.btnSklad.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnSklad.Size = new System.Drawing.Size(200, 40);
            this.btnSklad.TabIndex = 0;
            this.btnSklad.Text = "Оформить покупку";
            this.btnSklad.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSklad.UseVisualStyleBackColor = true;
            this.btnSklad.Click += new System.EventHandler(this.btnSklad_Click_1);
            // 
            // btnCatalogueMenu
            // 
            this.btnCatalogueMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCatalogueMenu.FlatAppearance.BorderSize = 0;
            this.btnCatalogueMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCatalogueMenu.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCatalogueMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCatalogueMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCatalogueMenu.Location = new System.Drawing.Point(0, 100);
            this.btnCatalogueMenu.Name = "btnCatalogueMenu";
            this.btnCatalogueMenu.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnCatalogueMenu.Size = new System.Drawing.Size(200, 45);
            this.btnCatalogueMenu.TabIndex = 1;
            this.btnCatalogueMenu.Text = "Каталог";
            this.btnCatalogueMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCatalogueMenu.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.TimeLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(950, 650);
            this.Controls.Add(this.panelChildForm);
            this.Controls.Add(this.panelSideMenu);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(950, 650);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главная форма";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.panelSideMenu.ResumeLayout(false);
            this.panelSkladSubMenu.ResumeLayout(false);
            this.panelCatalogueSubMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.Label TimeLabel;
        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button btnHelpMenu;
        private System.Windows.Forms.Panel panelSkladSubMenu;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button SkladCatalogue;
        private System.Windows.Forms.Button btnSkladMenu;
        private System.Windows.Forms.Panel panelCatalogueSubMenu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSklad;
        private System.Windows.Forms.Button btnCatalogueMenu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCreateDetails;
    }
}