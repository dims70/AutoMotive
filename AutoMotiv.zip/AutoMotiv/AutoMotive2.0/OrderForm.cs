﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImdLib7;

namespace AutoMotive2._0
{
    public partial class OrderForm : Form
    {
        public OrderForm()
        {
            InitializeComponent();
            dataGridViewSklad.FillDataGridFromQueryOleDB("*","Склад");
            dataGridViewSupplier.FillDataGridFromQueryOleDB("*", "Поставщик");
            comboIdDet.FillComboBoxFromQueryOleDB("КодЗапчасти","Склад");
            comboIdDet.SelectedItem = "(нет)";
            dataGridViewListOrders.FillDataGridFromLongQueryOleDB($"" +
                $"select КодПродажи," +
                $"(select НазваниеЗапчасти from Склад where КодЗапчасти = Продажи.КодЗапчасти)as Запчасть," +
                $"ДатаПродажи," +
                $"КодАвторизации," +
                $"Количество," +
                $"ИтоговаяСумма from Продажи", "Продажи");
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();

        private void countDetail_ValueChanged(object sender, EventArgs e)
        {
           if(countDetail.Value > 0)
            {
                btnSave.Enabled = true;
                summBox.Text = countDetail.Value * Convert.ToDecimal(
                    new OleDbCommand($"select МножительЦены from Поставщик " +
                    $"where КодПоставщика = {boxIdSupp.Text}",
                    ConnectionOleDB
                    .getConnection())
                    .ExecuteScalar()) 
                    * Convert.ToDecimal(
                    new OleDbCommand($"select СтоимостьЗаЕдиницу from Склад " +
                    $"where КодЗапчасти = {comboIdDet.SelectedItem}", 
                    ConnectionOleDB
                    .getConnection())
                    .ExecuteScalar()) + "";
            }
           else
            {
                btnSave.Enabled = false;
            }
        }

        private void comboIdDet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboIdDet.SelectedItem != "(нет)")
            {
                boxIdSupp.Text = new OleDbCommand($"select КодПоставщика from Склад " +
                $"where КодЗапчасти = {comboIdDet.SelectedItem + ""}", 
                ConnectionOleDB.getConnection())
                .ExecuteScalar()
                .ToString();
                var maxCount = Convert.ToDecimal(new OleDbCommand
                ($"select Количество from Склад " +
                $"where КодЗапчасти = {comboIdDet.SelectedItem + ""}",
                ConnectionOleDB.getConnection())
                .ExecuteScalar());
                countDetail.Maximum = maxCount;  
                countDetail.Enabled = true;
                countDetail.Value = default;
                summBox.Text = 0.ToString();

            }
            else
            {
                boxIdSupp.Text = 0.ToString();
                countDetail.Enabled = false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            new OleDbCommand($"update Склад set " +
                $"Количество = Количество - {countDetail.Value} " +
                $"where КодЗапчасти = {boxIdSupp.Text}",
                ConnectionOleDB
                .getConnection())
                .ExecuteNonQuery();
            new OleDbCommand($"insert into Продажи(КодЗапчасти," +
                $"ДатаПродажи," +
                $"КодАвторизации," +
                $"Количество," +
                $"ИтоговаяСумма) " +
                $"values (" +
                $"{comboIdDet.SelectedItem}," +
                $"'{DateTime.Today.ToShortDateString()}'," +
                $"{AuthUser.id}," +
                $"{countDetail.Value}," +
                $"'{summBox.Text}')",
                ConnectionOleDB.getConnection()).ExecuteNonQuery();
            MessageBox.Show("Покупка оформлена");
            dataGridViewSklad.FillDataGridFromQueryOleDB("*","Склад");
            dataGridViewListOrders.FillDataGridFromLongQueryOleDB($"select КодПродажи," +
                $"(select НазваниеЗапчасти from Склад where КодЗапчасти = Продажи.КодЗапчасти)as Запчасть," +
                $"ДатаПродажи," +
                $"КодАвторизации," +
                $"Количество," +
                $"ИтоговаяСумма from Продажи", "Продажи");
        }
    }
}
