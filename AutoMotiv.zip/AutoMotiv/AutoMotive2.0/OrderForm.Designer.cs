﻿namespace AutoMotive2._0
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboIdDet = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.summBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridViewSklad = new System.Windows.Forms.DataGridView();
            this.dataGridViewSupplier = new System.Windows.Forms.DataGridView();
            this.countDetail = new System.Windows.Forms.NumericUpDown();
            this.boxIdSupp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridViewListOrders = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSklad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSupplier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.countDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClose.Location = new System.Drawing.Point(590, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(148, 30);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Закрыть форму";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(311, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Выберите код запчасти";
            // 
            // comboIdDet
            // 
            this.comboIdDet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboIdDet.FormattingEnabled = true;
            this.comboIdDet.Items.AddRange(new object[] {
            "(нет)"});
            this.comboIdDet.Location = new System.Drawing.Point(286, 120);
            this.comboIdDet.Name = "comboIdDet";
            this.comboIdDet.Size = new System.Drawing.Size(178, 21);
            this.comboIdDet.TabIndex = 10;
            this.comboIdDet.SelectedIndexChanged += new System.EventHandler(this.comboIdDet_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(283, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Код поставщика";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(174, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Введите покупаемое количество";
            // 
            // summBox
            // 
            this.summBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.summBox.Location = new System.Drawing.Point(286, 286);
            this.summBox.Name = "summBox";
            this.summBox.ReadOnly = true;
            this.summBox.Size = new System.Drawing.Size(178, 20);
            this.summBox.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(328, 270);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Итоговая сумма";
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(286, 342);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(178, 39);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Оформить покупку";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dataGridViewSklad
            // 
            this.dataGridViewSklad.AllowUserToAddRows = false;
            this.dataGridViewSklad.AllowUserToDeleteRows = false;
            this.dataGridViewSklad.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSklad.Location = new System.Drawing.Point(13, 104);
            this.dataGridViewSklad.Name = "dataGridViewSklad";
            this.dataGridViewSklad.ReadOnly = true;
            this.dataGridViewSklad.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSklad.Size = new System.Drawing.Size(264, 277);
            this.dataGridViewSklad.TabIndex = 19;
            // 
            // dataGridViewSupplier
            // 
            this.dataGridViewSupplier.AllowUserToAddRows = false;
            this.dataGridViewSupplier.AllowUserToDeleteRows = false;
            this.dataGridViewSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSupplier.Location = new System.Drawing.Point(481, 104);
            this.dataGridViewSupplier.Name = "dataGridViewSupplier";
            this.dataGridViewSupplier.ReadOnly = true;
            this.dataGridViewSupplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSupplier.Size = new System.Drawing.Size(257, 277);
            this.dataGridViewSupplier.TabIndex = 20;
            // 
            // countDetail
            // 
            this.countDetail.Location = new System.Drawing.Point(286, 230);
            this.countDetail.Name = "countDetail";
            this.countDetail.Size = new System.Drawing.Size(178, 20);
            this.countDetail.TabIndex = 21;
            this.countDetail.ValueChanged += new System.EventHandler(this.countDetail_ValueChanged);
            // 
            // boxIdSupp
            // 
            this.boxIdSupp.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.boxIdSupp.Location = new System.Drawing.Point(286, 181);
            this.boxIdSupp.Name = "boxIdSupp";
            this.boxIdSupp.ReadOnly = true;
            this.boxIdSupp.Size = new System.Drawing.Size(178, 20);
            this.boxIdSupp.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(57, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "Список запчастей:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(513, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(191, 20);
            this.label6.TabIndex = 24;
            this.label6.Text = "Список поставщиков:";
            // 
            // dataGridViewListOrders
            // 
            this.dataGridViewListOrders.AllowUserToAddRows = false;
            this.dataGridViewListOrders.AllowUserToDeleteRows = false;
            this.dataGridViewListOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListOrders.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewListOrders.Location = new System.Drawing.Point(0, 414);
            this.dataGridViewListOrders.Name = "dataGridViewListOrders";
            this.dataGridViewListOrders.ReadOnly = true;
            this.dataGridViewListOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewListOrders.Size = new System.Drawing.Size(750, 236);
            this.dataGridViewListOrders.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(12, 391);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(240, 20);
            this.label7.TabIndex = 26;
            this.label7.Text = "Список последних покупок:";
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 650);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridViewListOrders);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.boxIdSupp);
            this.Controls.Add(this.countDetail);
            this.Controls.Add(this.dataGridViewSupplier);
            this.Controls.Add(this.dataGridViewSklad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.summBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboIdDet);
            this.Controls.Add(this.btnClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OrderForm";
            this.Text = "OrderForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSklad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSupplier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.countDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListOrders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboIdDet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox summBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridViewSklad;
        private System.Windows.Forms.DataGridView dataGridViewSupplier;
        private System.Windows.Forms.NumericUpDown countDetail;
        private System.Windows.Forms.TextBox boxIdSupp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridViewListOrders;
        private System.Windows.Forms.Label label7;
    }
}