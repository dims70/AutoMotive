﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;
using ImdLib7;

namespace AutoMotive2._0
{
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
            ConnectionOleDB.StringConnection = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Auto.accdb;";
            ConnectionOleDB.getConnection().Open();
        }

        private void btnAuth_Click(object sender, EventArgs e)
        {
            var cmd = new OleDbCommand($"select * from Авторизация where" +
                $" ИмяПользователя = '{loginbox.Text}'" +
                $" and " +
                $"Пароль = '{passwordbox.Text}'", ConnectionOleDB.getConnection());
            if (cmd.ExecuteScalar() != null)
            {
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    AuthUser.id = (int)reader[0];
                    AuthUser.login = (string)reader[1];
                }
                reader.Close();
                Hide();
                if(new MainForm().ShowDialog() == DialogResult.OK)
                {
                    Show();
                }
            }
            else
            {
                MessageBox.Show("Логин и/или пароль неверны!");
            }
        }
    }
}
