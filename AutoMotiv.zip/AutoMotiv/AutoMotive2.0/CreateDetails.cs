﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;
using ImdLib7;

namespace AutoMotive2._0
{
    public partial class CreateDetails : Form
    {
        public CreateDetails()
        {
            InitializeComponent();
            comboMarks.FillComboBoxFromQueryOleDB("КодМарки","Марка");
            comboModels.FillComboBoxFromQueryOleDB("КодМодели", "Модель");
            comboSupp.FillComboBoxFromQueryOleDB("КодПоставщика", "Поставщик");
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                new OleDbCommand($"insert into Склад" +
                    $"(КодМарки," +
                    $"КодМодели," +
                    $"КодПоставщика," +
                    $"НазваниеЗапчасти," +
                    $"СтоимостьЗаЕдиницу," +
                    $"Количество) " +
                    $"values " +
                    $"({comboMarks.SelectedItem}," +
                    $"{comboModels.SelectedItem}," +
                    $"{comboSupp.SelectedItem}," +
                    $"'{boxNameDet.Text}'," +
                    $"'{boxCostOne.Text}'," +
                    $"{boxStartCount.Text})",
                    ConnectionOleDB.getConnection()).ExecuteNonQuery();
                MessageBox.Show("Запчасть добавлена");
            }
            catch 
            {
                MessageBox.Show("Заполните все поля верно");
            }
        }
    }
}
