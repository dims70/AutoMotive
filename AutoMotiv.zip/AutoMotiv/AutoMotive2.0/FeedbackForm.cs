﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoMotive2._0
{
    public partial class FeedbackForm : Form
    {
        public FeedbackForm() => InitializeComponent();

        private void button1_Click(object sender, EventArgs e) => MessageBox.Show("Вопрос отправлен!");

        private void btnClose_Click(object sender, EventArgs e) => Close();
    }
}
